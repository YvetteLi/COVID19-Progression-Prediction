library(testthat)
library(coronaModel)

test_check("coronaModel")
